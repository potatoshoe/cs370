README
======

Josh Mau / 830-802-582
Homework 1
Jan. 17, 2017
CS370 Section 1

************************************
  'make all' or 'make' produces hw1 
  executable and 'make clean' removes 
  Object files.

************************************
